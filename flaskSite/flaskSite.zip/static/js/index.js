// Toggle grid padding -  Revamp for uploading user image
function tryNowButton() {
    // check if user is signed in.

    // if user is not signed in 
    //      redirect user to sign in page

    // if user is signed in
    //      rediect to user home page

}

// Open and close sidebar
function openSideBar() {
    document.getElementById("mySidebar").style.width = "100%";
    document.getElementById("mySidebar").style.display = "block";
}

function closeSideBar() {
    document.getElementById("mySidebar").style.display = "none";
}