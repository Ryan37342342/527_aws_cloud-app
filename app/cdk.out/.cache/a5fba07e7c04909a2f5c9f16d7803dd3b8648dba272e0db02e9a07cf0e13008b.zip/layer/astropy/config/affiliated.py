# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""This module contains functions and classes for finding information about
affiliated packages and installing them.
"""


__all__ = []
